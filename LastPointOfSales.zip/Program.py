"""
Run the program
"""

import POSView

#Launch the program
def main():
    UserChoice=""
    while UserChoice.lower() !="quit":
        UserChoice=POSView.main()
main()

