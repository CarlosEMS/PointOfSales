# -*- coding: utf-8 -*-
"""
Here will be all the code related to the Business Logic, Processes and checkings
"""

import POSModule
import POSView
import sys


"""
Desc: check if the user entered the word cancel to exit theprogram
Param:
Return:
"""
def CancelProgramCheck(InputStr):
    if InputStr.lower()=="cancel":
        sys.exit(0)

"""
Desc: Tells the customer that there is invalid Operation
Param:
Return:
"""
def InvalidInputOperation():
    POSView.PrintToUser("Invalid Operation")

"""
Desc: Checking on the user input selection to start the appropriate process
Param: string of the user input to check on it
Return:
"""
def ProceedWithUserSelection(UserChoice,newchoice):
    ''' check doc'''
    if UserChoice!="":
        UserChoice_Split=UserChoice.split()
    else:
        UserChoice_Split=["NoCommand"]
    EnteredCommand=UserChoice_Split[0].lower()
    while (len(UserChoice_Split)<=1 and EnteredCommand!="quit")  or not IsCommandValid(EnteredCommand) or len(UserChoice_Split)>5:
        InvalidInputOperation()
        UserChoice=POSView.GetUserChoice()
        UserChoice_Split=UserChoice.split()
        if UserChoice=="":
            UserChoice_Split=["NoCommand"]
        EnteredCommand=UserChoice_Split[0].lower()
    #Removing the command
    UserChoice_Split.remove(UserChoice_Split[0])
    newchoice.append(EnteredCommand)
    if EnteredCommand=="sale":
        SaleList=CheckSalesCommand(UserChoice_Split)
        if AddSalesc(SaleList)=="Success":
            return "The Sale successfuly added"
        else:
            return "Sale wasn't added, please try again later"
    elif EnteredCommand=="customer":
        pass
        #CheckCustomerCommand()
        #AddCustomer()
    elif EnteredCommand=="report":
        pass
        #GenerateReport()
    elif EnteredCommand=="crm":
        pass
        #CRM()
    elif EnteredCommand=="close day":
        pass
        #CloseOfDay()
    elif EnteredCommand=="quit":
        return "\nThanks for using POS System\n"

   

"""
Desc: Check if the entered command is valid to our list of commands or not
Param: Command entered by user
Return: 0 if invalid command, 1 if valid command
"""
def IsCommandValid(CheckCommand):
    if CheckCommand not in POSModule.GetInputCommands():
        return 0 #yes its invalide command
    else:
        return 1 #Command is valid
        



def CheckSalesCommand(UserChoice_Split):
    ArticleID=GetSkuFromSaleCommand(UserChoice_Split)
    CustomerID=GetCustomerFromSaleCommand(UserChoice_Split)
    CC=GetCCFromSaleCommand(UserChoice_Split)
    Amount=GetAmountFromSaleCommand(UserChoice_Split)
    return [ArticleID,CustomerID,CC,Amount] #return the sale list


def GetAmountFromSaleCommand(UserChoice_Split):
    Number_of_Arguments=len(UserChoice_Split)
    Amount=0
    InputMsg="Please Enter Valid Amount Number: "
    if Number_of_Arguments==1:
        Amount=int(CheckNumeric(UserChoice_Split[0],InputMsg))
    if Number_of_Arguments!=1:
        POSView.PrintToUser("Sale Amount is wrong!")
        Amount=int(CheckNumeric(GetUserInput(InputMsg),InputMsg))
    return Amount
        

def GetSkuFromSaleCommand(UserChoice_Split):
    for item in UserChoice_Split:
        if "sku:" in item.lower():
            InputMsg="Please Enter Valid Article Number: "
            ArticleID=CheckForNumberArguments(item,"The Article part was written with more than one ':'",InputMsg,2,":")
            ArticleID=CheckArticle(ArticleID,InputMsg)
            UserChoice_Split.remove(item)
            return ArticleID
    return 0 #means we didn't find it
    
def GetCustomerFromSaleCommand(UserChoice_Split):
    for item in UserChoice_Split:
        if "id:" in item.lower():
            InputMsg="Please Enter Valid Customer ID: "
            CustomerID=CheckForNumberArguments(item,"The Customer part was written with more than one ':'",InputMsg,2,":")
            CustomerID=CheckCustomer(CustomerID,InputMsg)
            UserChoice_Split.remove(item)
            return CustomerID
    return 0 #means we didn't find it
    
def GetCCFromSaleCommand(UserChoice_Split):
    for item in UserChoice_Split:
        if "cc" in item.lower():
            UserChoice_Split.remove(item)
            return 1
    return 0 #means we didn't find it

def CheckForNumberArguments(item,ErrorMsg,InputMsg,ArgumentNumber,SplitCharacter):
    SplitLength=len(item.split(SplitCharacter))
    while SplitLength!=ArgumentNumber:
        POSView.PrintToUser(ErrorMsg)
        return GetUserInput(InputMsg)
    return item.split(SplitCharacter)[1]


"""
Desc: Gets the user input with also checking if the user entered cancel to quit the program
Param: Message for the user of what to input
Return: string of the user input
"""
def GetUserInput(InputMsg):
    InputStr=POSView.InputFromUser(InputMsg)
    CancelProgramCheck(InputStr)
    return InputStr


"""
Desc: Check if the item (string) is numeric
Param: Item (string), Message for the user of what to input
Return: Item ID of type string
"""
def CheckNumeric(Item,MessageToUser):
    while not Item.isnumeric():
        POSView.PrintToUser("This is not a number")
        Item=GetUserInput(MessageToUser)
    return Item

"""
Desc: Return the Article that the user wants
Param: 
Return: Article ID that the user wants
"""
def CheckArticle(ArticleID,InputMsg):
    Article=GetArticleByIDc(ArticleID)
    while Article is None:
        POSView.ItemNotFound("Article")
        ArticleID=GetUserInput(InputMsg)
        Article=GetArticleByIDc(ArticleID)
    #print("The Article that was choosed is ", Article[0]," and its price is ",Article[1])
    return ArticleID
    
"""
Desc: Return the Customer that the user wants
Param: 
Return: Customer that the user wants
"""
def CheckCustomer(CustomerID,InputMsg):
    Article=GetCustomerByIDc(CustomerID)
    while Article is None:
        POSView.ItemNotFound("Customer")
        CustomerID=GetUserInput(InputMsg)
        Article=GetCustomerByIDc(CustomerID)
    return CustomerID

"""
Desc: Add a new sale
Param: 
Return: 
"""
def AddSales(SaleList):
    Article=GetArticleByID()
    print("\n")
    Customer=GetCustomerByID()
    print("\n")
    Quantity=GetQuantity()
    print("\n")
    Payment=GetPaymentType()
    print("\n")
    Status=POSController.AddSalesc(Article,Customer,Quantity,Payment)
    if Status=="Success":
        print("The Sale successfuly added for:")
        print("Article:",Article[1][0])
        print("Customer:",Customer[1])
        print("Quantity:",Quantity)
        print("Payment:",Payment)
        print("\n")
    else:
        print("Error: Sales couldn't be added")

"""
Desc: Returns the payment types
Param:
Return: List of payment types.
"""
def GetPaymentTypesc():
    return POSModule.GetPaymentTypesm()

"""
Desc: Returns the input commands of the system that can be used by the user
Param: None
Return: Dictionary of input commands
"""
def GetInputCommand():
    return POSModule.GetInputCommands()
    
"""
Desc: Returns the wanted Article if found and if not found return Nothing
Param: Article ID of type Integer
Return: Wanted Article or None
"""
def GetArticleByIDc(ArticleID):
    return POSModule.GetArticleByIDm(ArticleID)
    
"""
Desc: Returns the wanted Customer if found and if not found return Nothing
Param: Customer ID of type Integer
Return: Wanted Customer or None
"""
def GetCustomerByIDc(CustomerID):
    return POSModule.GetCustomerByIDm(CustomerID)
    
"""
Desc: Adds new Sale to the Sales
Param: SaleList
Return: Success string if Operation is done
"""
def AddSalesc(SaleList):
    return POSModule.AddSalesm(SaleList)
    
"""
Desc: Adds new Customer
Param: Customer Name
Return: Customer ID
"""
def AddCustomerc(CustomerName):
    return POSModule.AddCustomerm(CustomerName)

"""
Desc: Getting All Customers
Param: 
Return: All Customers
"""
def GetAllCustomersc():
    return POSModule.GetAllCustomersm()

"""
Desc: Getting All Sales
Param: 
Return: All Sales
"""
def GetAllSalesc():
    return POSModule.GetAllSalesm()
    
def BuildReport():
    DaySales=POSModule.GetAllSalesm()
    AllCustomers=POSModule.GetAllCustomersm()
    AllArtiles=POSModule.GetAllArticlesm()
    newlist=[]
    for item in DaySales:
        newlist.append((AllArtiles[item[0]][0],AllCustomers[item[1]],item[2],item[3],item[4]))
    return newlist