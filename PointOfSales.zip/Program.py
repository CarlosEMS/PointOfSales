# -*- coding: utf-8 -*-
"""
Created on Thu Feb 11 14:32:10 2016

@author: Ahmed
"""

import POSView

UserChoice=""
#Launch the program
while UserChoice.lower() !="quit":
    UserChoice=POSView.main()

