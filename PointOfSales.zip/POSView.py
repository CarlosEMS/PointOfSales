# -*- coding: utf-8 -*-
"""
Here will be all the code related to the view (screen)
"""

import POSController
import os

#Getting the inputs commands to show it to the user
#InputCommands=POSController.GetInputCommand()
#Intializing the User choice value with empty string
UserChoice=""


"""
Desc: Main function of the program
Param:
Return:
"""
def main():
    WelcomeMessage()
    UserChoice=GetUserChoice()
    newchoice=[]
    Status=POSController.ProceedWithUserSelection(UserChoice,newchoice)
    UserChoice=newchoice[0]
    print(Status)
    PressEnterToContinue()
    os.system('cls')
    return UserChoice


"""
Desc: Print the welcome message to the screen with POS menu
Param:
Return:
"""
def WelcomeMessage():
    print("""
    \t\tWelcome to POS system\n
    For adding sales, please use one of the following examples
    (1) Sale #Amount# – Cash sale of that amount number, i.e. Sale 1000
    (2) Sale #SKU:number – Sale of a item in stock, i.e. Sale SKU:10
    (3) Sale #Amount# #CC# - Credit card sales, i.e. Sale 1000 CC
    (4) Sale #Amount# #ID:9alfanumeric – Sale to a registered customer, i.e. Sale 90 ID:213dhj
    
    For adding new customer:
    Customer name ID:9alfanumeric” – New customer, i.e. Customer Peter ID:19beta
    
    For Close of Sales Day, just write Close day
    To Print sales for the day , write Report
    To print breakdown of sales for the day by client, write CRM
    To quit the menu, write quit
    """)
    print("Note: if you want to exist the program at anytime type cancel\n")


"""
Desc: Gets the user choice of the operation he wants to perform
Param:
#InputStr=InputFromUser("Please enter the operation you want to perform: ")
Return: string of the user input
"""
def GetUserChoice():
    InputStr=InputFromUser("Please enter the operation you want to perform: ")
    POSController.CancelProgramCheck(InputStr)
    return InputStr


"""
Desc: Gets the user input and trim the white spaces 
Param:
Return: string of the user input
"""
def InputFromUser(Msg):
    InputStr=input(Msg)
    InputStr=InputStr.strip() #Removing white spaces on left or right of the whole string
    return InputStr
    
"""
Desc: Print the message to the user, this was made to encapsulate the print command,
    so controller can call this function without caring how actually the print is done
Param:
Return: 
"""
def PrintToUser(Msg):
    return print(Msg)
    
"""
Desc: Just to pause the program, was made to use after finishing each process
Param:
Return:
"""
def PressEnterToContinue():
    return input("Press Any Key to Continue!!")

    
"""
Desc: print out that this item (Article or Customer, etc..) is not found
Param: string of name of the item
Return:
"""
def ItemNotFound(item):
    print("The ",item," wasn't found, please re-enter it again")





"""
Desc: Takes the quantity of sales from the user.
Param: 
Return: Quantity as string
"""
def EnterQuantity():
    InputStr=input("Please Enter the quantity:")
    InputStr=InputStr.strip()
    POSController.CancelProgram(InputStr)
    return InputStr
    

    
    
"""
Desc: Return the Quantity that the user wants
Param: 
Return: Quantity as interger number
"""
def GetQuantity():
    InputStr=EnterQuantity()
    while not InputStr.isnumeric():
        print("This is not a valid number, please enter a valid one")
        InputStr=EnterQuantity()
    while int(InputStr)<0:
        print("This is a negative number, please enter a valid positive number")
        InputStr=EnterQuantity()
    return int(InputStr)

"""
Desc: Takes the payment of sales from the user.
Param: 
Return: Payment as string
"""
def EnterPayment():
    nstr="Please choose the payment type "+ POSController.GetPaymentTypesc().__str__()+" :"
    InputStr=input(nstr)
    InputStr=InputStr.strip()
    POSController.CancelProgram(InputStr)
    return InputStr

"""
Desc: Return the Payment that the user wants
Param: 
Return: Payment as string
"""
def GetPaymentType():
    InputStr=EnterPayment()
    Payments=POSController.GetPaymentTypesc()
    while InputStr not in Payments:
        print("This is not a valid payment, please enter a valid one")
        InputStr=EnterPayment()
    return InputStr

"""
Desc: Takes the Customer Name from the user.
Param: 
Return: Customer Name as string
"""
def EnterCustomerName():
    CustomerName=input("Please Enter the Customer Name: ")
    CustomerName=CustomerName.strip()
    return CustomerName


"""
Desc: Adding New Customer
Param: 
Return:
"""
def AddCustomer():
    CustomerName=EnterCustomerName()
    while CustomerName=="":
        print("Wrong Entry")
        CustomerName=EnterCustomerName()
    NewCustomerID=POSController.AddCustomerc(CustomerName)
    if NewCustomerID>0:
        print("The Customer ",CustomerName," was successfuly added with new ID:",NewCustomerID)
    else:
        print("Error: Customer couldn't be added")

"""
Desc: Showing All Customers
Param: 
Return:
"""
def GetAllCustomers():
    print(POSController.GetAllCustomersc())
    
def GenerateReport():
    print(POSController.BuildReport())
    
    
